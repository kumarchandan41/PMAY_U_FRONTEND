import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-scheme-master',
  templateUrl: './scheme-master.component.html',
  styleUrls: ['./scheme-master.component.css']
})
export class SchemeMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
