import { Component, OnInit, ViewChild, TemplateRef } from '@angular/core'; 
import { HttpClient } from '@angular/common/http';
//import { Charts, District, States, City, FinDetails, CompMaster } from 'src/app/model/charts.model';

import { promise } from 'protractor';
import { Observable, never } from 'rxjs';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { lstatSync } from 'fs';
import { Alert } from 'selenium-webdriver';
import { NgbModal, NgbActiveModal, NgbProgressbar } from '@ng-bootstrap/ng-bootstrap';
import { Route, Router } from '@angular/router';
import { NgbInputDatepicker } from '@ng-bootstrap/ng-bootstrap'; 
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-admin-login-panel',
  templateUrl: './admin-login-panel.component.html',
  styleUrls: ['./admin-login-panel.component.css']
})
export class AdminLoginPanelComponent implements OnInit {
  StateMessage: string;
  DistrictMessage: string;
  CityMessage :string;
  stValue: string;
  distValue:string;
  cityValue :string;

  constructor(private router: Router,private formBuilder:FormBuilder) { 
    this.StateMessage = "Select State";
    this.DistrictMessage = "Select District";
    this.CityMessage = "Select City";
      this.stValue = "0";
      this.distValue = "0";
      this.cityValue = "0";
  }

  ngOnInit() {

  }

}
