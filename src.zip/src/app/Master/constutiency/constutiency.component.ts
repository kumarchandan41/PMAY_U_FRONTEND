import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-constutiency',
  templateUrl: './constutiency.component.html',
  styleUrls: ['./constutiency.component.css']
})
export class ConstutiencyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
