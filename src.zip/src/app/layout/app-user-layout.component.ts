import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-user-layout',
  templateUrl: './app-user-layout.component.html',
  styleUrls: ['./app-user-layout.component.css']
})
export class AppUserLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
