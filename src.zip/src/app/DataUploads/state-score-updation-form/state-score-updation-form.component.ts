import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-score-updation-form',
  templateUrl: './state-score-updation-form.component.html',
  styleUrls: ['./state-score-updation-form.component.css']
})
export class StateScoreUpdationFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
