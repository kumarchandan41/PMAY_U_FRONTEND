import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-role',
  templateUrl: './all-role.component.html',
  styleUrls: ['./all-role.component.css']
})
export class AllRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
