import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-all-assigned-role',
  templateUrl: './all-assigned-role.component.html',
  styleUrls: ['./all-assigned-role.component.css']
})
export class AllAssignedRoleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
